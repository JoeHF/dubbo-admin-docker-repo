# Dubbo admin

> dubbo admin front end and back end
![index](https://raw.githubusercontent.com/apache/incubator-dubbo-ops/develop/dubbo-admin-frontend/src/assets/index.png)
### front end
* Vue.js and Vuetify
* dubbo-admin-frontend/README.md for more detail

## Build setup 

``` bash
# build
mvn clean install

# run
mvn --projects dubbo-admin-backend spring-boot:run

# visit
localhost:8080 

```
